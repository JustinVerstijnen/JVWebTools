const tools = [
  {
    title: "DNS MEGAtool",
    description: "A simple and efficient tool to check configured DNS records for a domain or bulk domains. It also checks security options and includes an export function.",
    toolUrl: "https://tools.justinverstijnen.nl/dnsmegatool",
    shortcut: "https://dnsmegatool.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/DNSMegaTool",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-126a9332c712.png"
  },
  {
    title: "365 Records Generator",
    description: "Generate DNS records needed to configure a domain in Microsoft 365, including verification and SMTP DANE records, based on your domain and tenant name.",
    toolUrl: "https://tools.justinverstijnen.nl/365recordsgenerator",
    shortcut: "https://365recgen.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/365RecordsGenerator",
    image: "https://justinverstijnen.nl/wp-content/uploads/2026/01/jv-media-2375-e0a0d3966c58.png"
  },
  {
    title: "Subnet Calculator",
    description: "Calculate IPv4 networks and identify network configuration based on an IP address and subnet mask. Includes an export function.",
    toolUrl: "https://tools.justinverstijnen.nl/subnetcalculator",
    shortcut: "https://subnet.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/SubnetCalculator",
    image: "https://justinverstijnen.nl/wp-content/uploads/2026/01/jv-media-2375-a076cab1afde.png"
  },
  {
    title: "Password Generator",
    description: "Quickly generate passwords with options for character sets and excluding similar characters.",
    toolUrl: "https://tools.justinverstijnen.nl/passwordgenerator",
    shortcut: "https://password.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/PasswordGenerator",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/06/Schermafbeelding-2025-06-06-131444.png"
  },
  {
    title: "Registry to PowerShell",
    description: "Convert Registry files and keys to PowerShell scripts for Microsoft Intune, startup scripts and Active Directory Group Policies.",
    toolUrl: "https://tools.justinverstijnen.nl/registrytopowershell",
    shortcut: "https://reg2ps.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/RegistryToPowershell",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-b9204fb9fad6.png"
  },
  {
    title: "IP Lookup Tool",
    description: "Look up IPv4 or IPv6 addresses and view properties such as ISP, country, location and more. Includes export functionality.",
    toolUrl: "https://tools.justinverstijnen.nl/iplookuptool",
    shortcut: "https://iplookup.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/IPLookupTool",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-4f5f927edf77.png"
  },
  {
    title: "365 Tenant Lookup",
    description: "Search Microsoft 365 tenants by custom domain or .onmicrosoft.com domain to find the associated tenant ID and location.",
    toolUrl: "https://tools.justinverstijnen.nl/tenantlookuptool",
    shortcut: "https://tenantlookup.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/TenantLookupTool",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-191e1e49f781.png"
  },
  {
    title: "HTML Color Picker",
    description: "Pick HTML colors and look up HEX/RGB codes for your projects.",
    toolUrl: "https://tools.justinverstijnen.nl/htmlcolorpicker",
    shortcut: "https://htmlcolor.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/HTMLColorPicker",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-5d93369a5dbd.png"
  },
  {
    title: "Port Checker Tool",
    description: "Check whether TCP ports are open to the internet. Useful for troubleshooting firewall and DNAT rules.",
    toolUrl: "https://tools.justinverstijnen.nl/portchecker",
    shortcut: "https://portchecker.jvapp.nl",
    github: "https://github.com/JustinVerstijnen/PortCheckerTool",
    image: "https://justinverstijnen.nl/wp-content/uploads/2025/12/jv-media-2375-57b9bd3e99aa.png"
  }
];

const grid = document.getElementById("toolsGrid");
const searchInput = document.getElementById("searchInput");
const emptyState = document.getElementById("emptyState");

function githubSvg() {
  return `<span class="github-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 .5A12 12 0 0 0 8.2 23.9c.6.1.8-.3.8-.6v-2.1c-3.3.7-4-1.4-4-1.4-.5-1.3-1.3-1.7-1.3-1.7-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1.1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.6-.3-5.4-1.3-5.4-5.9 0-1.3.5-2.4 1.2-3.2-.1-.3-.5-1.5.1-3.2 0 0 1-.3 3.3 1.2a11.4 11.4 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.6 1.7.2 2.9.1 3.2.8.8 1.2 1.9 1.2 3.2 0 4.6-2.8 5.6-5.4 5.9.4.4.8 1.1.8 2.2v3.2c0 .3.2.7.8.6A12 12 0 0 0 12 .5Z"/></svg></span>`;
}

function createToolCard(tool) {
  const article = document.createElement("article");
  article.className = "tool-card";
  article.innerHTML = `
    <a class="tool-image-link" href="${tool.toolUrl}" target="_blank" rel="noopener noreferrer" aria-label="Open ${tool.title}">
      <img class="tool-image" src="${tool.image}" alt="${tool.title} preview" loading="lazy" />
    </a>
    <div class="tool-content">
      <h2 class="tool-title">${tool.title}</h2>
      <p class="tool-description">${tool.description}</p>
      <div class="tool-actions">
        <a class="tool-primary" href="${tool.toolUrl}" target="_blank" rel="noopener noreferrer">Use tool</a>
        <a class="tool-github" href="${tool.github}" target="_blank" rel="noopener noreferrer">${githubSvg()} GitHub</a>
      </div>
      <a class="shortcut-link" href="${tool.shortcut}" target="_blank" rel="noopener noreferrer">${tool.shortcut.replace("https://", "")}</a>
    </div>
  `;
  return article;
}

function renderTools(query = "") {
  const search = query.trim().toLowerCase();
  const filtered = tools.filter((tool) => {
    return [tool.title, tool.description, tool.shortcut, tool.github]
      .join(" ")
      .toLowerCase()
      .includes(search);
  });

  grid.innerHTML = "";
  filtered.forEach((tool) => grid.appendChild(createToolCard(tool)));
  emptyState.style.display = filtered.length ? "none" : "block";
}

searchInput.addEventListener("input", (event) => renderTools(event.target.value));
renderTools();
